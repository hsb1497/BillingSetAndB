package com.cg.mra.client;

import java.util.Scanner;

public class MainClass {
	
	public static void main(String args[])
	{
	String mobNo;
	double mobBalance;
		
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter mobile No");
	mobNo=sc.next();
	System.out.println("Your current balance");
	mobBalance=sc.nextDouble();
	

	}
}
