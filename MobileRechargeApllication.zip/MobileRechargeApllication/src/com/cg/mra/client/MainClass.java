package com.cg.mra.client;

import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.AccountNotFoundException;
import com.cg.mra.exception.AmountNotCorrectException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.IAccountService;

public class MainClass {
	
	public static void main(String args[])
	{
		
	IAccountService accountService=new AccountService();
	Scanner sc=new Scanner(System.in);	
	String mobNo;
	double rechargeAmount;
	while(true)
	{
    System.out.println("1. Account Balance Enquiry");
    System.out.println("2.Recharge Account");
    System.out.println("3.Exit");
	int choice=sc.nextInt();
	switch(choice)
	{
	case 1:
	        System.out.println("Enter mobile No");
	        mobNo=sc.next();
		try {
			
			System.out.println("Current Balance is:"+accountService.getAccountDetails(mobNo).getAccountBalance());
		} catch (AccountNotFoundException e) {
			
			e.printStackTrace();
		    
		}
	        
	        break;
	        
	case 2: 
	        System.out.println("Enter Mobile Number");
	        mobNo=sc.next();
	        try
	        {
	        accountService.getAccountDetails(mobNo);
	        
	        System.out.println("Enter Recharge amount");
	        rechargeAmount=sc.nextDouble();
	        
		    System.out.println("Recharge succesfull");
		    		System.out.println(" New Balance is:"+accountService.rechargeAccount(mobNo, rechargeAmount));
		    
		} catch (AmountNotCorrectException | AccountNotFoundException e ) {
			e.printStackTrace();
		}
	   
	        break;
	
	case 3: System.exit(0);
	        break;
	}
	
	try {
		Thread.sleep(1000);      // for delayed menu display and not in between exception message display. 
	} catch (InterruptedException e) {
		e.printStackTrace();
	}
	
  }
 }
}    
