package com.cg.mra.dao;

import java.util.HashMap;

import com.cg.mra.beans.Account;

public class AccountDAO implements IAccountDAO{

	public static HashMap<String, Account>AccountEntry=new HashMap<String, Account>();
	
	public AccountDAO()
	{
		
		AccountEntry.put("9010210131", new Account("Prepaid", "VAISHALI", 200));
		AccountEntry.put("9823920123", new Account("Prepaid", "MEGHA",453));
		AccountEntry.put("9932012345", new Account("Prepaid", "VIKAS", 631));
		AccountEntry.put("9010210123", new Account("Prepaid", "ANJU", 521));
		AccountEntry.put("9010210133", new Account("Prepaid", "TUSHAR", 632));
			
	}
	
	@Override
	public Account getAccountDetails(String mobNo) {
		
		return AccountDAO.AccountEntry.get(mobNo);
		
	}

	@Override
	public double rechargeAccount(String mobNo, double rechargeAmount) {
		
		double newBalance=AccountDAO.AccountEntry.get(mobNo).getAccountBalance()+ rechargeAmount;
		AccountDAO.AccountEntry.get(mobNo).setAccountBalance(newBalance);
		return AccountDAO.AccountEntry.get(mobNo).getAccountBalance(); 
	}
	
	

}
