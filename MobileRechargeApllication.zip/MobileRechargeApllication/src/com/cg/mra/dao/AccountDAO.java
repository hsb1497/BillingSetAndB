package com.cg.mra.dao;

public class AccountDAO {

}
