package com.cg.mra.dao;

import com.cg.mra.beans.Account;

public interface IAccountDAO {
	Account getAccountDetails(String mobNo);
	double rechargeAccount(String mobNo,double rechargeAmount);
	

}
