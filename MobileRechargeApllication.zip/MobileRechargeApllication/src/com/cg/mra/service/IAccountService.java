package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.AccountNotFoundException;
import com.cg.mra.exception.AmountNotCorrectException;

public interface IAccountService {

	Account getAccountDetails(String mobileNo) throws AccountNotFoundException;
	double rechargeAccount(String mobileNo,double rechargeAmount) throws AmountNotCorrectException;
	
}
