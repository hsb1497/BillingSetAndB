package com.cg.mra.service;

public class IAccountService {

}
