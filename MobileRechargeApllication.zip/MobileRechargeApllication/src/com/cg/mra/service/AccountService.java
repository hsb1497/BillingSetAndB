package com.cg.mra.service;



import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDAO;
import com.cg.mra.dao.IAccountDAO;
import com.cg.mra.exception.AccountNotFoundException;
import com.cg.mra.exception.AmountNotCorrectException;

public class AccountService implements IAccountService {

	IAccountDAO accountDao=new AccountDAO(); 
		
		
	@Override
	public Account getAccountDetails(String mobileNo) throws AccountNotFoundException{
		
		if(accountDao.getAccountDetails(mobileNo)==null)
		 throw new AccountNotFoundException("your mobile number is incorrect");
		
		else 
			return accountDao.getAccountDetails(mobileNo);
			
	}

	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) throws AmountNotCorrectException{
		
		if(rechargeAmount>0)
		return accountDao.rechargeAccount(mobileNo, rechargeAmount);
		
		else
			throw new AmountNotCorrectException("Your Recharge Amount cannot be negative");
	}

	
}
