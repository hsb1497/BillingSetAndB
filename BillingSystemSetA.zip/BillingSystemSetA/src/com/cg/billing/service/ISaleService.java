package com.cg.billing.service;

import java.util.HashMap;

import com.cg.billing.beans.Sale;
import com.cg.billing.exception.InvalidProductCategoryException;
import com.cg.billing.exception.InvalidProductCodeException;
import com.cg.billing.exception.InvalidProductNameException;
import com.cg.billing.exception.PriceNotCorrectException;
import com.cg.billing.exception.QuantityNotCorrectException;

public interface ISaleService {
	
	public HashMap<Integer,Sale>insertSalesDetails(Sale sale) throws InvalidProductCategoryException, InvalidProductCodeException, 
	InvalidProductNameException, PriceNotCorrectException, QuantityNotCorrectException;
	
	
	public boolean validateProductCode(int prodCode) throws InvalidProductCodeException;
	boolean validateQuantity(int quantity)throws QuantityNotCorrectException;
	public boolean validateProductCat(String prodCat) throws InvalidProductCategoryException;
	public boolean validateProductName(String prodName) throws InvalidProductNameException;
	public boolean validateProductPrice(int prodPrice) throws PriceNotCorrectException;
	
}
