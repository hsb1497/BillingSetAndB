package com.cg.billing.exception;

public class PriceNotCorrectException extends Exception {

	public PriceNotCorrectException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PriceNotCorrectException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public PriceNotCorrectException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public PriceNotCorrectException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public PriceNotCorrectException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
