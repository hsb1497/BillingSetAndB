package com.cg.billing.beans;

import java.time.LocalDate;
import java.util.Date;

public class Sale {

	private int saleId;
	private int prodCode;
	private String prodName;
	private String category;
	private Date date;
	private int prodQuantity;
	private float lineTotal;
	
	public Sale() {
		super();
	}

	public Sale(int saleId, int prodCode, String prodName, String category, Date date, int prodQuantity,
			float lineTotal) {
		super();
		this.saleId = saleId;
		this.prodCode = prodCode;
		this.prodName = prodName;
		this.category = category;
		this.date = date;
		this.prodQuantity = prodQuantity;
		this.lineTotal = lineTotal;
	}
	
	public Sale( int prodCode, String prodName, String category,/*  Date date*/int prodQuantity,
			float lineTotal) {
		super();
		this.prodCode = prodCode;
		this.prodName = prodName;
		this.category = category;
		//this.date = date;
		this.prodQuantity = prodQuantity;
		this.lineTotal = lineTotal;
	}

	public int getSaleId() {
		return saleId;
	}

	public void setSaleId(int saleId) {
		this.saleId = saleId;
	}

	public int getProdCode() {
		return prodCode;
	}

	public void setProdCode(int prodCode) {
		this.prodCode = prodCode;
	}

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public int getProdQuantity() {
		return prodQuantity;
	}

	public void setProdQuantity(int prodQuantity) {
		this.prodQuantity = prodQuantity;
	}

	public float getLineTotal() {
		return lineTotal;
	}

	public void setLineTotal(float lineTotal) {
		this.lineTotal = lineTotal;
	}

	@Override
	public String toString() {
		return "Sale [saleId=" + saleId + ", prodCode=" + prodCode + ", prodName=" + prodName + ", category=" + category
				+ ", date=" + date + ", prodQuantity=" + prodQuantity + ", lineTotal=" + lineTotal + "]";
	}
	
	
	
	
}
