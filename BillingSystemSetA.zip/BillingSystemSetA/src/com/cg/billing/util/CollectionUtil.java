
package com.cg.billing.util;


import java.util.Date;
import java.util.HashMap;

import com.cg.billing.beans.Sale;

public class CollectionUtil {
	
	

	private static HashMap<Integer,Sale>sales=new HashMap<Integer,Sale>();
	
	private static Date date=new Date();
	
	public static Date createDate()
	{
	 return date;
	}
	
	public static int generateSaleId()
	{
		return (int)(1000+(Math.random()*1000));
	}
	
	/*
	 public static HashMap<Integer, Sale> getSales() {
		return sales;
	}

	public static void setSales(HashMap<Integer, Sale> sales) {
		CollectionUtil.sales = sales;
	}
	
	public static HashMap<Integer, Sale>setCollection()
	{
		return CollectionUtil.sales=sale;
	}
	
	*/
	
    public static HashMap<Integer,Sale> getCollection(){
	
			return sales;
	}
	

}
