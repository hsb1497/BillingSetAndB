package com.cg.billing.client;

import java.util.Scanner;

import com.cg.billing.beans.Sale;
import com.cg.billing.exception.InvalidProductCategoryException;
import com.cg.billing.exception.InvalidProductCodeException;
import com.cg.billing.exception.InvalidProductNameException;
import com.cg.billing.exception.PriceNotCorrectException;
import com.cg.billing.exception.QuantityNotCorrectException;
import com.cg.billing.service.ISaleService;
import com.cg.billing.service.SaleService;

public class MainClass {
	public static void main(String args[])
	{
		ISaleService saleService=new SaleService();
		int prodCode1=0,quantity = 0,prodPrice=0;
		String prodCat="",prodName="";
		while(true) {
			

			
			
			

			Scanner sc=new Scanner(System.in);

			try {
				System.out.println("Enter the product code");
				prodCode1=sc.nextInt();
				saleService.validateProductCode(prodCode1);
			} catch (InvalidProductCodeException e) {
				System.out.println(e.getMessage());

			}

		
			try {
				System.out.println("Enter the product quantity");
				quantity=sc.nextInt();
				saleService.validateQuantity(quantity);
			} catch (QuantityNotCorrectException e) {
				System.out.println(e.getMessage());


			}

			
			try {
				System.out.println("Enter the product category");
				prodCat=sc.next();
				saleService.validateProductCat(prodCat);
			} catch (InvalidProductCategoryException e) {
				System.out.println(e.getMessage());

			}
			
			try {
				System.out.println("Enter the product Name");
				prodName=sc.next();
				saleService.validateProductName(prodName);
			} catch (InvalidProductNameException e) {
				System.out.println(e.getMessage());

			}
			
			try {
				System.out.println("Enter the product Price");
				prodPrice=sc.nextInt();
				saleService.validateProductPrice(prodPrice);
			} catch (PriceNotCorrectException e) {
				System.out.println(e.getMessage());

			}
			
			Sale sale =new Sale(prodCode1, prodName, prodCat,quantity,prodPrice*quantity);
			
			try {
				System.out.println(saleService.insertSalesDetails(sale));
			} catch (InvalidProductCategoryException e) {			
				e.printStackTrace();
			} catch (InvalidProductCodeException e) {
				e.printStackTrace();
			} catch (InvalidProductNameException e) {
				e.printStackTrace();
			} catch (PriceNotCorrectException e) {
				e.printStackTrace();
			} catch (QuantityNotCorrectException e) {
				e.printStackTrace();
			}		
					}

	}
}