package com.cg.project.client;

import java.util.Scanner;

import com.cg.project.beans.Product;
import com.cg.project.exception.InvalidProductDetailException;
import com.cg.project.exception.QuantityExceededException;
import com.cg.project.services.IProductService;
import com.cg.project.services.ProductService;

public class MainClass {

	public static void main(String[] args) {

		IProductService prodService=new ProductService();

		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the product code");
		int prodCode=sc.nextInt();

		System.out.println("Enter the quantity");
		int prodQuantity=sc.nextInt();

		try {
			System.out.println(prodService.getProductDetails(prodCode));
		} catch (InvalidProductDetailException e) {

			System.out.println(e.getMessage());
		}

		Product product = null;
		try {
			product = prodService.getProductDetails(prodCode);

			System.out.println("The quantity is:"+prodQuantity);
			System.out.println("The total price is:"+prodService.calculatePrice(product, prodQuantity));

		} catch (InvalidProductDetailException | QuantityExceededException e) {
			System.out.println(e.getMessage());
		}

		
		
	}

}
