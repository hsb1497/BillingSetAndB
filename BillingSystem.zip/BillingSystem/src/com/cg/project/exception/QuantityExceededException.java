package com.cg.project.exception;

public class QuantityExceededException extends Exception {

	public QuantityExceededException() {
		super();
		
	}

	public QuantityExceededException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

	public QuantityExceededException(String message, Throwable cause) {
		super(message, cause);
	
	}

	public QuantityExceededException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public QuantityExceededException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	

}
