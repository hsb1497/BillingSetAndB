package com.cg.project.services;

import com.cg.project.beans.Product;
import com.cg.project.exception.InvalidProductDetailException;
import com.cg.project.exception.QuantityExceededException;

public interface IProductService {
	
	Product getProductDetails(int prodCode) throws InvalidProductDetailException;
	
    int calculatePrice(Product product,int quantity)throws QuantityExceededException;
	

}
