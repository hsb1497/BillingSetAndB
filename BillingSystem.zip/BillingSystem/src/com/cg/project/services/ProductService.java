package com.cg.project.services;

import org.omg.CORBA.DynAnyPackage.Invalid;

import com.cg.project.beans.Product;
import com.cg.project.dao.IProductDAO;
import com.cg.project.dao.ProductDAO;
import com.cg.project.exception.InvalidProductDetailException;
import com.cg.project.exception.QuantityExceededException;
import com.cg.project.util.CollectionUtil;

public class ProductService implements IProductService{

	IProductDAO prodDao=new ProductDAO();
	@Override
	public Product getProductDetails(int prodCode) throws InvalidProductDetailException{

		Product productobj=prodDao.getProductDetails(prodCode);
	
		if(productobj!=null)
		{
			return productobj;
		}
		else
			throw new InvalidProductDetailException("Sorry! product code is invalid");
		
	}
	
	public int calculatePrice(Product product, int quantity) throws QuantityExceededException{
		
		if(quantity>=1)
		{
			int totalPrice=(product.getProductPrice())*quantity;
			return totalPrice;
		}
		else 
			throw new QuantityExceededException("The Quantity can not be zero or negative");	
		
	}

	

}