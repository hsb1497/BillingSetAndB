package com.cg.project.dao;

import com.cg.project.beans.Product;

public interface IProductDAO {

	Product getProductDetails(int productId);
}
