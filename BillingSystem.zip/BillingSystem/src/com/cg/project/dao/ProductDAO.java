package com.cg.project.dao;

import com.cg.project.beans.Product;
import com.cg.project.util.CollectionUtil;

public class ProductDAO implements IProductDAO{

	@Override
	public Product getProductDetails(int prodCode) {
	
			
		
		return CollectionUtil.products.get(prodCode);
	}

	
	

}
