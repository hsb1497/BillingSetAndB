package com.cg.takehome.exceptions;

public class ProductDetailsNotfoundException extends Exception {

	public ProductDetailsNotfoundException() {
		// TODO Auto-generated constructor stub
	}

	public ProductDetailsNotfoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ProductDetailsNotfoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public ProductDetailsNotfoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ProductDetailsNotfoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
